﻿namespace ClienteSockets
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Username1TextBox = new System.Windows.Forms.TextBox();
            this.Password1TextBox = new System.Windows.Forms.TextBox();
            this.buttonLogIn = new System.Windows.Forms.Button();
            this.Username2TextBox = new System.Windows.Forms.TextBox();
            this.Password2TextBox = new System.Windows.Forms.TextBox();
            this.buttonRegister = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGreen;
            this.button1.Location = new System.Drawing.Point(25, 295);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(306, 102);
            this.button1.TabIndex = 1;
            this.button1.Text = "CONNECT TO THE SERVER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Username1TextBox
            // 
            this.Username1TextBox.Location = new System.Drawing.Point(286, 50);
            this.Username1TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Username1TextBox.Name = "Username1TextBox";
            this.Username1TextBox.Size = new System.Drawing.Size(100, 22);
            this.Username1TextBox.TabIndex = 3;
            this.Username1TextBox.Text = "Username";
            // 
            // Password1TextBox
            // 
            this.Password1TextBox.Location = new System.Drawing.Point(408, 50);
            this.Password1TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Password1TextBox.Name = "Password1TextBox";
            this.Password1TextBox.Size = new System.Drawing.Size(100, 22);
            this.Password1TextBox.TabIndex = 4;
            this.Password1TextBox.Text = "Password";
            this.Password1TextBox.TextChanged += new System.EventHandler(this.Password1TextBox_TextChanged);
            // 
            // buttonLogIn
            // 
            this.buttonLogIn.Location = new System.Drawing.Point(356, 77);
            this.buttonLogIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonLogIn.Name = "buttonLogIn";
            this.buttonLogIn.Size = new System.Drawing.Size(75, 23);
            this.buttonLogIn.TabIndex = 5;
            this.buttonLogIn.Text = "LOG IN";
            this.buttonLogIn.UseVisualStyleBackColor = true;
            this.buttonLogIn.Click += new System.EventHandler(this.buttonLogIn_Click);
            // 
            // Username2TextBox
            // 
            this.Username2TextBox.Location = new System.Drawing.Point(276, 129);
            this.Username2TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Username2TextBox.Name = "Username2TextBox";
            this.Username2TextBox.Size = new System.Drawing.Size(100, 22);
            this.Username2TextBox.TabIndex = 9;
            this.Username2TextBox.Text = "Username";
            // 
            // Password2TextBox
            // 
            this.Password2TextBox.Location = new System.Drawing.Point(408, 129);
            this.Password2TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Password2TextBox.Name = "Password2TextBox";
            this.Password2TextBox.Size = new System.Drawing.Size(100, 22);
            this.Password2TextBox.TabIndex = 10;
            this.Password2TextBox.Text = "Password";
            // 
            // buttonRegister
            // 
            this.buttonRegister.Location = new System.Drawing.Point(345, 157);
            this.buttonRegister.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonRegister.Name = "buttonRegister";
            this.buttonRegister.Size = new System.Drawing.Size(96, 23);
            this.buttonRegister.TabIndex = 11;
            this.buttonRegister.Text = "REGISTER";
            this.buttonRegister.UseVisualStyleBackColor = true;
            this.buttonRegister.Click += new System.EventHandler(this.buttonRegister_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.Location = new System.Drawing.Point(469, 295);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(306, 102);
            this.button2.TabIndex = 12;
            this.button2.Text = "DISCONNECT THE SERVER";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonRegister);
            this.Controls.Add(this.Password2TextBox);
            this.Controls.Add(this.Username2TextBox);
            this.Controls.Add(this.buttonLogIn);
            this.Controls.Add(this.Password1TextBox);
            this.Controls.Add(this.Username1TextBox);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Username1TextBox;
        private System.Windows.Forms.TextBox Password1TextBox;
        private System.Windows.Forms.Button buttonLogIn;
        private System.Windows.Forms.TextBox Username2TextBox;
        private System.Windows.Forms.TextBox Password2TextBox;
        private System.Windows.Forms.Button buttonRegister;
        private System.Windows.Forms.Button button2;
    }
}

