﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClienteSockets
{
    public partial class Form2 : Form
    {
        private Socket server;
        private string username;

        private Form1 form1Original;

        int conectado = 0;
        int login = 0;

        public Form2(Socket server, string username, Form1 form1Original)
        {
            InitializeComponent();
            this.server = server;
            this.username = username;
            this.form1Original = form1Original;
        }


        private void SendQuery(string queryType)
        {
            try
            {
                string mensaje = queryType + username;
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                Console.WriteLine("Mensaje enviado al servidor: " + mensaje);

                byte[] msg2 = new byte[512];
                int bytesRecibidos = server.Receive(msg2);
                string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos);
                MessageBox.Show(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al enviar la consulta: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.form1Original.Show(); // Vuelve a mostrar el form original
            this.Close(); // Cierra el Form2 actual
        }

        public int GetConectado()
        {
            return this.conectado;
        }

        public int GetLogin()
        {
            return this.login;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SendQuery("1/");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SendQuery("2/");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            SendQuery("3/");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string mensaje = "4/";
            //Enviamos al servidor el nombre y contraseña tecleados
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            byte[] msg2 = new byte[512];
            int bytesRecibidos = server.Receive(msg2);
            string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos);
            MessageBox.Show(respuesta);
        }
    }
}
